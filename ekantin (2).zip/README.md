# E-Kantin (Pembaruan status pelanggan dan dashboard petugas)

- Pelanggan: http://localhost:3000
- Petugas: http://localhost:3000/dapur.html (PIN awal 1234)
- Status pesanan di halaman pelanggan terhubung langsung ke dashboard petugas dan diperbarui otomatis setiap 5 detik.
- Pesanan terakhir disimpan di browser pelanggan agar tetap bisa dipantau setelah refresh pada perangkat yang sama.

## Jalankan
1. Start MySQL (XAMPP/Laragon).
2. Di folder project: `npm install`
3. Setup database: `npm run setup` (jika belum)
4. Start: `npm start`
5. Buka alamat pelanggan atau petugas di atas.

Konfigurasi database dan PIN dapat diubah di `config.js`.
