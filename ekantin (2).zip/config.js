// Ubah nilai di sini sesuai MySQL kamu.
// (XAMPP/Laragon biasanya: user "root" dan password kosong)
module.exports = {
  port: process.env.PORT || 3000,
  staffPin: process.env.STAFF_PIN || '1234', // PIN untuk halaman petugas (dapur.html)
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'ekantin',
  },
};
