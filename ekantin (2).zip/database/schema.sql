-- E-Kantin: jalankan file ini di MySQL
-- Cara: mysql -u root -p < database/schema.sql
--       (atau salin isinya ke phpMyAdmin / MySQL Workbench lalu Run)

CREATE DATABASE IF NOT EXISTS ekantin
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ekantin;

-- Daftar menu
CREATE TABLE IF NOT EXISTS menu (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  nama      VARCHAR(100) NOT NULL,
  kategori  ENUM('Makanan','Minuman','Cemilan') NOT NULL,
  harga     INT UNSIGNED NOT NULL,
  stok      INT UNSIGNED NOT NULL DEFAULT 0,
  aktif     TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_menu_nama (nama)
) ENGINE=InnoDB;

-- Pesanan (satu baris per pemesan). Nomor antri mulai dari 1 setiap hari.
CREATE TABLE IF NOT EXISTS pesanan (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  tanggal       DATE NOT NULL,
  no_antri      INT NOT NULL,
  nama_pemesan  VARCHAR(100) NOT NULL,
  kelas         VARCHAR(50) NULL,
  catatan       VARCHAR(255) NULL,
  total         INT UNSIGNED NOT NULL,
  status        ENUM('menunggu','diterima','diproses','siap','selesai')
                NOT NULL DEFAULT 'menunggu',
  dibuat        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_antri_harian (tanggal, no_antri),
  KEY idx_status (status)
) ENGINE=InnoDB;

-- Rincian item tiap pesanan (dihapus otomatis jika pesanan dihapus)
CREATE TABLE IF NOT EXISTS pesanan_item (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  pesanan_id  INT NOT NULL,
  menu_id     INT NOT NULL,
  nama        VARCHAR(100) NOT NULL,
  harga       INT UNSIGNED NOT NULL,
  qty         INT UNSIGNED NOT NULL,
  CONSTRAINT fk_item_pesanan FOREIGN KEY (pesanan_id)
    REFERENCES pesanan(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Menu awal (aman dijalankan berulang kali)
INSERT IGNORE INTO menu (nama, kategori, harga, stok) VALUES
  ('Nasi Goreng Spesial', 'Makanan', 15000, 20),
  ('Mie Ayam Bakso',      'Makanan', 13000, 20),
  ('Ayam Penyet',         'Makanan', 17000, 15),
  ('Es Teh Manis',        'Minuman',  4000, 40),
  ('Es Jeruk',            'Minuman',  6000, 30),
  ('Susu Coklat',         'Minuman',  7000, 25),
  ('Pisang Goreng',       'Cemilan',  5000, 25),
  ('Kentang Goreng',      'Cemilan',  8000, 20),
  ('Tahu Crispy',         'Cemilan',  6000, 20);
