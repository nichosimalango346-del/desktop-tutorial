const mysql = require('mysql2/promise');
const config = require('./config');

const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true, // tanggal/waktu dikirim sebagai teks apa adanya
});

module.exports = pool;
