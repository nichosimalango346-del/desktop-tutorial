let pin = sessionStorage.getItem('pin') || '';
let semua = false;
let timer = null;

const $ = (id) => document.getElementById(id);
const rp = (n) => 'Rp' + Number(n).toLocaleString('id-ID');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STATUS = { menunggu: 'Menunggu', diterima: 'Diterima', diproses: 'Disiapkan', siap: 'Siap diambil', selesai: 'Selesai' };
const TOMBOL = { menunggu: 'Terima pesanan', diterima: 'Mulai siapkan', diproses: 'Tandai siap', siap: 'Selesai diambil' };

async function api(url, opt = {}) {
  opt.headers = Object.assign({ 'x-pin': pin, 'Content-Type': 'application/json' }, opt.headers);
  const res = await fetch(url, opt);
  if (res.status === 401) { keluar(); throw new Error('PIN'); }
  return res;
}

function tampilLogin() {
  clearInterval(timer);
  $('app').hidden = true;
  $('login').hidden = false;
  $('pin').focus();
}

function keluar() {
  pin = '';
  sessionStorage.removeItem('pin');
  tampilLogin();
}

async function masuk() {
  pin = $('pin').value;
  const res = await fetch('/api/dapur/cek', { headers: { 'x-pin': pin } });
  if (!res.ok) { $('lerr').textContent = 'PIN salah.'; return; }
  sessionStorage.setItem('pin', pin);
  $('lerr').textContent = '';
  mulai();
}

function mulai() {
  $('login').hidden = true;
  $('app').hidden = false;
  muat();
  clearInterval(timer);
  timer = setInterval(muat, 5000);
}

async function muat() {
  try {
    const res = await api('/api/dapur/pesanan' + (semua ? '?semua=1' : ''));
    const data = await res.json();
    $('info').textContent = data.length + ' pesanan · diperbarui ' + new Date().toLocaleTimeString('id-ID');
    const aktif = data.filter(p => p.status !== 'selesai');
    $('statAktif').textContent = aktif.length;
    $('statMenunggu').textContent = data.filter(p => p.status === 'menunggu').length;
    $('statProses').textContent = data.filter(p => ['diterima','diproses'].includes(p.status)).length;
    $('statSiap').textContent = data.filter(p => p.status === 'siap').length;
    $('list').innerHTML = data.length ? data.map(kartu).join('') : '<div class="empty">Belum ada pesanan.</div>';
  } catch (e) { /* login ulang ditangani di api() */ }
}

function kartu(p) {
  return `<div class="card">
    <div class="top"><span class="kode">${p.kode}</span><span class="badge${p.status === 'siap' ? ' siap' : ''}">${STATUS[p.status]}</span></div>
    <div><b>${esc(p.nama_pemesan)}</b>${p.kelas ? ' · ' + esc(p.kelas) : ''} <span class="note">· ${esc(p.dibuat ? new Date(p.dibuat).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '')}</span></div>
    <div>${p.items.map((i) => `<div class="row"><span>${i.qty} × ${esc(i.nama)}</span><span>${rp(i.harga * i.qty)}</span></div>`).join('')}</div>
    <div class="tot"><span>Total</span><span>${rp(p.total)}</span></div>
    ${p.catatan ? `<div class="catat"><b>Catatan:</b> ${esc(p.catatan)}</div>` : ''}
    <div class="btns">
      ${TOMBOL[p.status] ? `<button class="go" type="button" data-lanjut="${p.id}">${TOMBOL[p.status]}</button>` : ''}
      <button class="bad" type="button" data-hapus="${p.id}" data-kode="${p.kode}">Hapus pesanan</button>
    </div>
  </div>`;
}

document.addEventListener('click', async (e) => {
  const lanjut = e.target.dataset && e.target.dataset.lanjut;
  const hapus = e.target.dataset && e.target.dataset.hapus;
  if (lanjut) {
    const res = await api(`/api/dapur/pesanan/${lanjut}/lanjut`, { method: 'PATCH' });
    if (!res.ok) alert((await res.json()).error);
    muat();
  }
  if (hapus && confirm(`Hapus pesanan ${e.target.dataset.kode}? Stok akan dikembalikan jika belum selesai.`)) {
    const res = await api('/api/dapur/pesanan/' + hapus, { method: 'DELETE' });
    if (!res.ok && res.status !== 204) alert((await res.json()).error);
    muat();
  }
});

$('masuk').onclick = masuk;
$('pin').addEventListener('keydown', (e) => { if (e.key === 'Enter') masuk(); });
$('keluar').onclick = keluar;
$('tAktif').onclick = () => { semua = false; $('tAktif').className = 'tab on'; $('tSemua').className = 'tab'; muat(); };
$('tSemua').onclick = () => { semua = true; $('tSemua').className = 'tab on'; $('tAktif').className = 'tab'; muat(); };

if (pin) {
  fetch('/api/dapur/cek', { headers: { 'x-pin': pin } }).then((r) => (r.ok ? mulai() : keluar()));
} else {
  tampilLogin();
}
