let menu = [];
let cart = {};
let poll = null;
let trackedOrder = null;
let menuWarning = '';
const DEMO_MENU = [
{id:901,nama:'Nasi Goreng Spesial',kategori:'Makanan',harga:15000,stok:20},
{id:902,nama:'Mie Ayam Bakso',kategori:'Makanan',harga:13000,stok:20},
{id:903,nama:'Ayam Penyet',kategori:'Makanan',harga:17000,stok:15},
{id:904,nama:'Es Teh Manis',kategori:'Minuman',harga:4000,stok:40},
{id:905,nama:'Es Jeruk',kategori:'Minuman',harga:6000,stok:30},
{id:906,nama:'Susu Coklat',kategori:'Minuman',harga:7000,stok:25},
{id:907,nama:'Pisang Goreng',kategori:'Cemilan',harga:5000,stok:25},
{id:908,nama:'Kentang Goreng',kategori:'Cemilan',harga:8000,stok:20},
{id:909,nama:'Tahu Crispy',kategori:'Cemilan',harga:6000,stok:20}
];

const $ = (id) => document.getElementById(id);
const rp = (n) => 'Rp' + Number(n).toLocaleString('id-ID');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STATUS = { menunggu: 'Menunggu diterima', diterima: 'Pesanan diterima', diproses: 'Sedang disiapkan', siap: 'Siap diambil!', selesai: 'Selesai' };

async function muatMenu() {
  try {
    const res = await fetch('/api/menu');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    menu = Array.isArray(data) ? data : [];
    menuWarning = menu.length ? '' : 'Database menu kosong. Menampilkan menu contoh. Jalankan npm run setup untuk mengisi database.';
    if (!menu.length) menu = DEMO_MENU.map(x => ({...x}));
  } catch (err) {
    menu = DEMO_MENU.map(x => ({...x}));
    menuWarning = 'API/database belum terhubung. Menu contoh ditampilkan; pesanan belum dapat disimpan. Periksa MySQL lalu jalankan npm run setup.';
  }
  render();
}

function render() {
  let h = '';
  ['Makanan', 'Minuman', 'Cemilan'].forEach((k) => {
    const daftar = menu.filter((m) => m.kategori === k);
    if (!daftar.length) return;
    h += `<h2>${k}</h2><div class="grid">`;
    daftar.forEach((m) => {
      const n = cart[m.id] || 0;
      const sisa = m.stok - n;
      h += `<div class="item"><b>${esc(m.nama)}</b><span class="price">${rp(m.harga)}</span>
        <span class="stock${sisa <= 3 ? ' low' : ''}">Stok: ${sisa}${sisa <= 0 ? ' (habis)' : ''}</span>`;
      if (n === 0) {
        h += `<button type="button" data-add="${m.id}"${sisa <= 0 ? ' disabled' : ''}>Tambah</button>`;
      } else {
        h += `<div class="qty"><button class="ghost" type="button" data-min="${m.id}" aria-label="Kurangi">−</button><b>${n}</b>
          <button class="ghost" type="button" data-add="${m.id}" aria-label="Tambah"${sisa <= 0 ? ' disabled' : ''}>+</button></div>`;
      }
      h += '</div>';
    });
    h += '</div>';
  });
  $('menu').innerHTML = (menuWarning ? `<div class="empty" style="margin-bottom:12px">${esc(menuWarning)}</div>` : '') + (h || '<div class="empty">Menu belum tersedia saat ini.</div>'); 

  const ids = Object.keys(cart);
  let total = 0;
  $('items').innerHTML = ids.length
    ? ids.map((id) => {
        const m = menu.find((x) => x.id == id);
        total += m.harga * cart[id];
        return `<div class="row"><span>${cart[id]} × ${esc(m.nama)}</span><span>${rp(m.harga * cart[id])}</span></div>`;
      }).join('')
    : '<div class="empty">Belum ada menu dipilih.</div>';
  $('total').textContent = rp(total);
}

const TRACK_KEY = 'ekantin_tracking_order';
const TRACK_STEPS = [
  ['menunggu', 'Menunggu'], ['diterima', 'Diterima'], ['diproses', 'Disiapkan'], ['siap', 'Siap diambil'], ['selesai', 'Selesai']
];
function progressIndex(status) { return Math.max(0, TRACK_STEPS.findIndex(([s]) => s === status)); }
function tampilPelacakan(order) {
  if (!order) { $('pelacakan').hidden = true; return; }
  trackedOrder = order;
  $('pelacakan').hidden = false;
  $('trackKode').textContent = order.kode || '';
  $('trackNama').textContent = order.nama || order.nama_pemesan || '';
  $('trackWaktu').textContent = order.dibuat ? 'Dipesan ' + new Date(order.dibuat).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '';
  const status = order.status || 'menunggu';
  $('trackBadge').textContent = STATUS[status] || status;
  $('trackBadge').className = 'badge' + (status === 'siap' ? ' siap' : status === 'selesai' ? ' selesai' : '');
  $('trackPesan').textContent = status === 'siap' ? `Pesanan ${order.nama || 'kamu'} sudah siap—silakan ambil di kantin!` : status === 'selesai' ? 'Pesanan sudah selesai. Terima kasih!' : status === 'diproses' ? 'Petugas sedang menyiapkan pesanan.' : status === 'diterima' ? 'Pesanan sudah diterima petugas.' : 'Pesanan masuk ke antrean, tunggu sebentar ya.';
  const idx = progressIndex(status);
  $('trackProgress').style.width = (status === 'selesai' ? 100 : Math.max(8, idx * 25)) + '%';
  $('trackSteps').innerHTML = TRACK_STEPS.map(([key,label],i)=>`<div class="step ${i<=idx?'active':''} ${key===status?'current':''}"><span class="dot">${i<=idx?'✓':i+1}</span><span>${label}</span></div>`).join('');
  const items = order.items || [];
  $('trackItems').innerHTML = items.length ? `<details><summary>Rincian pesanan</summary>${items.map(i=>`<div class="row"><span>${i.qty} × ${esc(i.nama)}</span><span>${rp(i.harga*i.qty)}</span></div>`).join('')}<div class="tot"><span>Total</span><span>${rp(order.total||items.reduce((a,i)=>a+i.harga*i.qty,0))}</span></div></details>` : '';
}
async function cekPesananTersimpan() {
  try {
    const saved = JSON.parse(localStorage.getItem(TRACK_KEY) || 'null');
    if (!saved || !saved.id) return;
    const res = await fetch('/api/pesanan/' + saved.id);
    if (!res.ok) { localStorage.removeItem(TRACK_KEY); tampilPelacakan(null); return; }
    const data = await res.json();
    tampilPelacakan({...saved,...data});
    if (data.status !== 'selesai') pantau(saved.id);
  } catch(e) { /* localStorage/status check can be retried next refresh */ }
}
$('trackTutup').onclick = () => { $('pelacakan').hidden = true; };

document.addEventListener('click', (e) => {
  const add = e.target.dataset && e.target.dataset.add;
  const min = e.target.dataset && e.target.dataset.min;
  if (add) {
    const m = menu.find((x) => x.id == add);
    if ((cart[add] || 0) < Math.min(m.stok, 20)) { cart[add] = (cart[add] || 0) + 1; $('err').textContent = ''; render(); }
  }
  if (min) {
    cart[min]--;
    if (cart[min] <= 0) delete cart[min];
    render();
  }
});

function tampilStatus(s) {
  $('status').textContent = STATUS[s.status] || s.status;
  $('status').className = 'badge' + (s.status === 'siap' ? ' siap' : '');
  $('depan').textContent =
    s.status === 'siap' ? 'Silakan ambil pesananmu di kantin.'
    : s.status === 'selesai' ? 'Terima kasih sudah memesan!'
    : s.di_depan > 0 ? `Ada ${s.di_depan} antrian di depanmu.` : 'Kamu berikutnya!';
}

async function pantau(id) {
  clearInterval(poll);
  poll = setInterval(async () => {
    try {
      const res = await fetch('/api/pesanan/' + id);
      if (res.status === 404) { clearInterval(poll); $('depan').textContent = 'Pesanan ini sudah tidak ada di daftar petugas.'; localStorage.removeItem(TRACK_KEY); tampilPelacakan(null); return; }
      const s = await res.json();
      tampilStatus(s);
      if (trackedOrder) tampilPelacakan({...trackedOrder, ...s});
      if (s.status === 'selesai') clearInterval(poll);
    } catch (e) { /* abaikan, coba lagi 5 detik berikutnya */ }
  }, 5000);
}

$('kirim').onclick = async () => {
  const nama = $('nama').value.trim();
  if (!nama) { $('err').textContent = 'Isi nama pemesan dulu.'; $('nama').focus(); return; }
  if (!Object.keys(cart).length) { $('err').textContent = 'Pilih minimal satu menu.'; return; }
  if (menuWarning) { $('err').textContent = 'Database belum siap. Jalankan npm run setup dan pastikan MySQL aktif, lalu refresh halaman.'; return; }
  $('kirim').disabled = true;
  try {
    const res = await fetch('/api/pesanan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nama, kelas: $('kelas').value.trim(), catatan: $('catatan').value.trim(),
        items: Object.keys(cart).map((id) => ({ id: Number(id), qty: cart[id] })),
      }),
    });
    const data = await res.json();
    if (!res.ok) { $('err').textContent = data.error || 'Gagal membuat pesanan'; await muatMenu(); return; }
    $('err').textContent = '';
    $('kode').textContent = data.kode;
    $('rincian').innerHTML =
      `<div><b>${esc(data.nama)}</b>${data.kelas ? ' · ' + esc(data.kelas) : ''}</div>` +
      data.items.map((i) => `<div class="row"><span>${i.qty} × ${esc(i.nama)}</span><span>${rp(i.harga * i.qty)}</span></div>`).join('') +
      `<div class="tot"><span>Total</span><span>${rp(data.total)}</span></div>` +
      (data.catatan ? `<div class="note">Catatan: ${esc(data.catatan)}</div>` : '');
    const savedOrder = {...data, dibuat: new Date().toISOString(), di_depan: Math.max(0, parseInt(data.kode.slice(1), 10) - 1)};
    localStorage.setItem(TRACK_KEY, JSON.stringify(savedOrder));
    tampilStatus(savedOrder);
    tampilPelacakan(savedOrder);
    $('ov').className = 'show';
    pantau(data.id);
  } catch (e) {
    $('err').textContent = 'Server tidak bisa dihubungi. Pastikan npm start masih berjalan.';
  } finally {
    $('kirim').disabled = false;
  }
};

$('baru').onclick = async () => {
  clearInterval(poll);
  $('ov').className = '';
  cart = {};
  $('catatan').value = '';
  $('nama').value = '';
  $('kelas').value = '';
  await muatMenu();
};

muatMenu();
cekPesananTersimpan();
