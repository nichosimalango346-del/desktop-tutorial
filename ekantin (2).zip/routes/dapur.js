const express = require('express');
const pool = require('../db');
const config = require('../config');
const { wrap, kode } = require('../util');
const router = express.Router();

// Semua route petugas dilindungi PIN (header x-pin)
router.use((req, res, next) => {
  if (req.get('x-pin') !== config.staffPin) return res.status(401).json({ error: 'PIN salah' });
  next();
});

router.get('/cek', (req, res) => res.json({ ok: true }));

// Pesanan hari ini. ?semua=1 ikut menampilkan yang sudah selesai
router.get('/pesanan', wrap(async (req, res) => {
  const filter = req.query.semua === '1' ? '' : "AND status <> 'selesai'";
  const [rows] = await pool.query(`SELECT * FROM pesanan WHERE tanggal = CURDATE() ${filter} ORDER BY no_antri`);
  const perPesanan = {};
  if (rows.length) {
    const [items] = await pool.query(
      'SELECT pesanan_id, nama, harga, qty FROM pesanan_item WHERE pesanan_id IN (?)',
      [rows.map((r) => r.id)]
    );
    items.forEach((it) => (perPesanan[it.pesanan_id] = perPesanan[it.pesanan_id] || []).push(it));
  }
  res.json(rows.map((r) => ({ ...r, kode: kode(r.no_antri), items: perPesanan[r.id] || [] })));
}));

// Maju ke status berikutnya: menunggu -> diterima -> diproses -> siap -> selesai
const BERIKUT = { menunggu: 'diterima', diterima: 'diproses', diproses: 'siap', siap: 'selesai' };
router.patch('/pesanan/:id/lanjut', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT status FROM pesanan WHERE id = ?', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
  const next = BERIKUT[rows[0].status];
  if (!next) return res.status(400).json({ error: 'Pesanan sudah selesai' });
  const [r] = await pool.query('UPDATE pesanan SET status = ? WHERE id = ? AND status = ?', [next, req.params.id, rows[0].status]);
  if (!r.affectedRows) return res.status(409).json({ error: 'Status sudah berubah, muat ulang daftar' });
  res.json({ id: Number(req.params.id), status: next });
}));

// Hapus pesanan. Jika belum selesai, stok dikembalikan ke menu.
router.delete('/pesanan/:id', wrap(async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT status FROM pesanan WHERE id = ? FOR UPDATE', [req.params.id]);
    if (!rows[0]) {
      await conn.rollback();
      return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
    }
    if (rows[0].status !== 'selesai') {
      await conn.query(
        'UPDATE menu m JOIN pesanan_item i ON i.menu_id = m.id SET m.stok = m.stok + i.qty WHERE i.pesanan_id = ?',
        [req.params.id]
      );
    }
    await conn.query('DELETE FROM pesanan WHERE id = ?', [req.params.id]);
    await conn.commit();
    res.status(204).end();
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}));

module.exports = router;
