const express = require('express');
const pool = require('../db');
const { wrap } = require('../util');
const router = express.Router();

// Daftar menu aktif untuk pembeli
router.get('/', wrap(async (req, res) => {
  const [rows] = await pool.query(
    "SELECT id, nama, kategori, harga, stok FROM menu WHERE aktif = 1 ORDER BY FIELD(kategori,'Makanan','Minuman','Cemilan'), id"
  );
  res.json(rows);
}));

module.exports = router;
