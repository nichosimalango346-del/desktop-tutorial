const express = require('express');
const pool = require('../db');
const { Input, wrap, kode } = require('../util');
const router = express.Router();

// Buat pesanan dalam satu transaksi: cek stok, kurangi stok, beri nomor antri
async function buat({ nama, kelas, catatan, items }) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    let total = 0;
    const baris = [];
    for (const it of items) {
      const [rows] = await conn.query('SELECT * FROM menu WHERE id = ? AND aktif = 1 FOR UPDATE', [it.id]);
      const m = rows[0];
      if (!m) throw new Input('Ada menu yang tidak tersedia lagi');
      if (m.stok < it.qty) throw new Input(`Stok ${m.nama} tinggal ${m.stok}`);
      total += m.harga * it.qty;
      baris.push({ m, qty: it.qty });
    }

    const [[n]] = await conn.query(
      'SELECT COALESCE(MAX(no_antri), 0) + 1 AS n FROM pesanan WHERE tanggal = CURDATE() FOR UPDATE'
    );
    const [ins] = await conn.query(
      'INSERT INTO pesanan (tanggal, no_antri, nama_pemesan, kelas, catatan, total) VALUES (CURDATE(), ?, ?, ?, ?, ?)',
      [n.n, nama, kelas || null, catatan || null, total]
    );

    for (const { m, qty } of baris) {
      await conn.query(
        'INSERT INTO pesanan_item (pesanan_id, menu_id, nama, harga, qty) VALUES (?, ?, ?, ?, ?)',
        [ins.insertId, m.id, m.nama, m.harga, qty]
      );
      await conn.query('UPDATE menu SET stok = stok - ? WHERE id = ?', [qty, m.id]);
    }

    await conn.commit();
    return {
      id: ins.insertId,
      no_antri: n.n,
      kode: kode(n.n),
      nama,
      kelas: kelas || null,
      catatan: catatan || null,
      total,
      status: 'menunggu',
      items: baris.map(({ m, qty }) => ({ nama: m.nama, harga: m.harga, qty })),
    };
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

// Pembeli membuat pesanan
router.post('/', wrap(async (req, res) => {
  const nama = String(req.body.nama || '').trim().slice(0, 100);
  const kelas = String(req.body.kelas || '').trim().slice(0, 50);
  const catatan = String(req.body.catatan || '').trim().slice(0, 255);
  if (!nama) throw new Input('Nama pemesan wajib diisi');

  // Gabungkan item yang sama dan urutkan agar tidak saling mengunci
  const gabung = new Map();
  for (const it of Array.isArray(req.body.items) ? req.body.items : []) {
    const id = parseInt(it.id, 10);
    const qty = parseInt(it.qty, 10);
    if (!(id > 0) || !(qty > 0) || qty > 20) throw new Input('Jumlah pesanan tidak valid');
    gabung.set(id, (gabung.get(id) || 0) + qty);
  }
  if (!gabung.size) throw new Input('Pilih minimal satu menu');
  const items = [...gabung].sort((a, b) => a[0] - b[0]).map(([id, qty]) => ({ id, qty }));

  // Ulangi jika dua pesanan masuk bersamaan dan nomor antrinya bentrok
  for (let i = 0; i < 3; i++) {
    try {
      return res.status(201).json(await buat({ nama, kelas, catatan, items }));
    } catch (e) {
      if (e.code !== 'ER_DUP_ENTRY' || i === 2) throw e;
    }
  }
}));

// Pembeli memantau status pesanannya
router.get('/:id', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id, tanggal, no_antri, nama_pemesan, kelas, catatan, total, dibuat, status FROM pesanan WHERE id = ?', [req.params.id]);
  const p = rows[0];
  if (!p) return res.status(404).json({ error: 'Pesanan tidak ditemukan (mungkin sudah dihapus)' });
  const [[d]] = await pool.query(
    "SELECT COUNT(*) AS n FROM pesanan WHERE tanggal = ? AND no_antri < ? AND status IN ('menunggu','diterima','diproses')",
    [p.tanggal, p.no_antri]
  );
  const [items] = await pool.query('SELECT nama, harga, qty FROM pesanan_item WHERE pesanan_id = ?', [p.id]);
  res.json({ id: p.id, kode: kode(p.no_antri), nama: p.nama_pemesan, kelas: p.kelas, catatan: p.catatan, total: p.total, dibuat: p.dibuat, items, status: p.status, di_depan: d.n });
}));

module.exports = router;
