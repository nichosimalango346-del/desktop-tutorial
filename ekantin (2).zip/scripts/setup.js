// Menjalankan database/schema.sql lewat Node: npm run setup
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const config = require('../config');

(async () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
  const { database, ...koneksi } = config.db;
  try {
    const conn = await mysql.createConnection({ ...koneksi, multipleStatements: true });
    await conn.query(sql);
    await conn.end();
    console.log('Database "' + database + '" siap dipakai.');
  } catch (e) {
    console.error('Gagal menyiapkan database:', e.message);
    console.error('Periksa MySQL sudah menyala dan user/password di config.js.');
    process.exit(1);
  }
})();
