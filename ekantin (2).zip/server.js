const express = require('express');
const path = require('path');
const config = require('./config');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/menu', require('./routes/menu'));
app.use('/api/pesanan', require('./routes/pesanan'));
app.use('/api/dapur', require('./routes/dapur'));

app.use((req, res) => res.status(404).json({ error: 'Tidak ditemukan' }));

app.listen(config.port, () => {
  console.log(`E-Kantin berjalan di http://localhost:${config.port}`);
  console.log(`Halaman petugas: http://localhost:${config.port}/dapur.html`);
});
