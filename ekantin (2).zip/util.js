// Kesalahan akibat input pengguna (dikirim sebagai 400)
class Input extends Error {}

// Menangkap error pada route async
const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => {
    if (e instanceof Input) return res.status(400).json({ error: e.message });
    console.error(e);
    res.status(500).json({ error: 'Terjadi kesalahan di server' });
  });

const kode = (n) => 'A' + String(n).padStart(3, '0');

module.exports = { Input, wrap, kode };
