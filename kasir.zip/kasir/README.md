# Kasir Warung Kita

Express + SQLite. Jalankan:

    npm install
    npm start

Buka http://localhost:3000
