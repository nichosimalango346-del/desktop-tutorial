const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'data');
fs.mkdirSync(dir, { recursive: true });

const db = new Database(path.join(dir, 'kasir.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS produk (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT NOT NULL,
    kategori TEXT NOT NULL,
    harga INTEGER NOT NULL,
    stok INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS transaksi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    no_struk TEXT,
    waktu TEXT NOT NULL,
    subtotal INTEGER NOT NULL,
    potongan INTEGER NOT NULL,
    total INTEGER NOT NULL,
    metode TEXT NOT NULL,
    diterima INTEGER,
    kembalian INTEGER
  );
  CREATE TABLE IF NOT EXISTS transaksi_item (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaksi_id INTEGER NOT NULL REFERENCES transaksi(id),
    produk_id INTEGER NOT NULL,
    nama TEXT NOT NULL,
    harga INTEGER NOT NULL,
    qty INTEGER NOT NULL
  );
`);

// Isi menu awal jika tabel produk masih kosong
if (db.prepare('SELECT COUNT(*) AS n FROM produk').get().n === 0) {
  const ins = db.prepare('INSERT INTO produk (nama, kategori, harga, stok) VALUES (?, ?, ?, ?)');
  const awal = [
    ['Nasi Goreng Spesial', 'Makanan', 25000, 12],
    ['Mie Ayam Bakso', 'Makanan', 20000, 10],
    ['Ayam Penyet', 'Makanan', 28000, 8],
    ['Es Teh Manis', 'Minuman', 6000, 25],
    ['Es Jeruk', 'Minuman', 9000, 18],
    ['Kopi Susu', 'Minuman', 15000, 14],
    ['Pisang Goreng', 'Cemilan', 12000, 15],
    ['Kentang Goreng', 'Cemilan', 14000, 9],
    ['Tahu Crispy', 'Cemilan', 10000, 3],
  ];
  db.transaction(() => awal.forEach((r) => ins.run(...r)))();
}

module.exports = db;
