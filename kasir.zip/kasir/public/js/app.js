let produk = [];
let cart = {};
let metode = 'tunai';

const $ = (id) => document.getElementById(id);
const rp = (n) => 'Rp' + Math.round(n).toLocaleString('id-ID');
const cari = (id) => produk.find((p) => p.id == id);

async function muatProduk() {
  const res = await fetch('/api/produk');
  produk = await res.json();
  render();
}

function hitung() {
  let sub = 0;
  for (const id in cart) sub += cari(id).harga * cart[id];
  const v = Math.max(0, parseFloat($('dval').value) || 0);
  const d = $('dtype').value === 'pct' ? (sub * Math.min(v, 100)) / 100 : Math.min(v, sub);
  return { sub, d, tot: sub - d };
}

function renderMenu() {
  let h = '';
  ['Makanan', 'Minuman', 'Cemilan'].forEach((k) => {
    h += `<h2>${k}</h2><div class="grid">`;
    produk.filter((p) => p.kategori === k).forEach((p) => {
      const sisa = p.stok - (cart[p.id] || 0);
      h += `<div class="item"><b>${p.nama}</b><span class="price">${rp(p.harga)}</span>
        <span class="stock${sisa <= 3 ? ' low' : ''}">Stok: ${sisa}${sisa === 0 ? ' (habis)' : ''}</span>
        <button type="button" data-add="${p.id}"${sisa <= 0 ? ' disabled' : ''}>Tambah</button></div>`;
    });
    h += '</div>';
  });
  $('menu').innerHTML = h;
}

function renderCart() {
  const ids = Object.keys(cart);
  let h = ids.length ? '' : '<div class="empty">Belum ada pesanan.</div>';
  ids.forEach((id) => {
    const p = cari(id);
    h += `<div class="row"><div><b>${p.nama}</b><br><span class="note">${rp(p.harga)}</span></div>
      <div class="qty"><button class="ghost" type="button" data-min="${id}" aria-label="Kurangi">−</button>
      <span>${cart[id]}</span>
      <button class="ghost" type="button" data-add="${id}" aria-label="Tambah"${cart[id] >= p.stok ? ' disabled' : ''}>+</button></div></div>`;
  });
  $('items').innerHTML = h;
  const c = hitung();
  $('sub').textContent = rp(c.sub);
  $('dsc').textContent = '-' + rp(c.d);
  $('tot').textContent = rp(c.tot);
  const dibayar = parseFloat($('paid').value) || 0;
  $('chg').textContent = c.tot > 0 ? (dibayar >= c.tot ? 'Kembalian: ' + rp(dibayar - c.tot) : 'Kurang: ' + rp(c.tot - dibayar)) : '';
}

function render() { renderMenu(); renderCart(); }

document.addEventListener('click', (e) => {
  const add = e.target.dataset && e.target.dataset.add;
  const min = e.target.dataset && e.target.dataset.min;
  if (add && (cart[add] || 0) < cari(add).stok) {
    cart[add] = (cart[add] || 0) + 1;
    $('err').textContent = '';
    render();
  }
  if (min) {
    cart[min]--;
    if (cart[min] <= 0) delete cart[min];
    render();
  }
});

['dval', 'dtype', 'paid'].forEach((id) => $(id).addEventListener('input', renderCart));

function setMetode(m) {
  metode = m;
  $('pT').className = m === 'tunai' ? 'on' : '';
  $('pQ').className = m === 'qris' ? 'on' : '';
  $('cash').hidden = m !== 'tunai';
  $('qris').hidden = m !== 'qris';
  $('err').textContent = '';
}
$('pT').onclick = () => setMetode('tunai');
$('pQ').onclick = () => setMetode('qris');

// Gambar QR simulasi
(function () {
  const pos = [[0, 0], [14, 0], [0, 14]];
  const finder = (i, j) => pos.find((c) => i >= c[0] && i < c[0] + 7 && j >= c[1] && j < c[1] + 7);
  let x = '';
  for (let j = 0; j < 21; j++) {
    for (let i = 0; i < 21; i++) {
      const f = finder(i, j);
      let on;
      if (f) {
        const a = i - f[0], b = j - f[1];
        on = a === 0 || a === 6 || b === 0 || b === 6 || (a >= 2 && a <= 4 && b >= 2 && b <= 4);
      } else on = (i * 7 + j * 13 + i * j) % 3 === 0;
      if (on) x += `<rect x="${i}" y="${j}" width="1" height="1" fill="#000"/>`;
    }
  }
  $('qr').innerHTML = x;
})();

function tampilStruk(t) {
  const w = new Date(t.waktu);
  const rows = t.items.map((it) =>
    `<div>${it.nama}</div><div class="l"><span>${it.qty} x ${rp(it.harga)}</span><span>${rp(it.harga * it.qty)}</span></div>`).join('');
  $('struk').innerHTML = `<h3>WARUNG KITA</h3><div class="c">Struk Pembayaran</div><hr>
    <div class="l"><span>No. ${t.no_struk}</span><span>${w.toLocaleDateString('id-ID')}</span></div>
    <div>${w.toLocaleTimeString('id-ID')}</div><hr>${rows}<hr>
    <div class="l"><span>Subtotal</span><span>${rp(t.subtotal)}</span></div>
    <div class="l"><span>Potongan</span><span>-${rp(t.potongan)}</span></div>
    <div class="l"><b>TOTAL</b><b>${rp(t.total)}</b></div><hr>
    <div class="l"><span>Metode</span><span>${t.metode === 'tunai' ? 'Tunai' : 'QRIS'}</span></div>
    ${t.metode === 'tunai' ? `<div class="l"><span>Diterima</span><span>${rp(t.diterima)}</span></div><div class="l"><span>Kembalian</span><span>${rp(t.kembalian)}</span></div>` : ''}
    <hr><div class="c">Terima kasih!<br>Selamat menikmati</div>`;
  $('ov').className = 'show';
  $('cls').focus();
}

$('go').onclick = async () => {
  const c = hitung();
  if (!c.sub) { $('err').textContent = 'Tambahkan pesanan dulu.'; return; }
  const body = {
    items: Object.keys(cart).map((id) => ({ id: Number(id), qty: cart[id] })),
    potongan: { tipe: $('dtype').value, nilai: parseFloat($('dval').value) || 0 },
    metode,
    diterima: parseFloat($('paid').value) || 0,
  };
  try {
    const res = await fetch('/api/transaksi', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) { $('err').textContent = data.error || 'Gagal memproses pembayaran'; return; }
    $('err').textContent = '';
    tampilStruk(data);
  } catch (e) {
    $('err').textContent = 'Server tidak bisa dihubungi. Pastikan npm start masih berjalan.';
  }
};

$('prt').onclick = () => window.print();
$('cls').onclick = async () => {
  $('ov').className = '';
  cart = {};
  $('dval').value = '';
  $('paid').value = '';
  await muatProduk();
};

muatProduk();
