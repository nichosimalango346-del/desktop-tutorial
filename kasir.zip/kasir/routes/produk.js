const express = require('express');
const db = require('../db');
const router = express.Router();

// Daftar produk
router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM produk ORDER BY id').all());
});

// Tambah produk
router.post('/', (req, res) => {
  const { nama, kategori, harga, stok } = req.body;
  if (!nama || !['Makanan', 'Minuman', 'Cemilan'].includes(kategori) || !(harga >= 0) || !(stok >= 0)) {
    return res.status(400).json({ error: 'Data produk tidak valid' });
  }
  const info = db
    .prepare('INSERT INTO produk (nama, kategori, harga, stok) VALUES (?, ?, ?, ?)')
    .run(nama, kategori, Math.round(harga), Math.round(stok));
  res.status(201).json(db.prepare('SELECT * FROM produk WHERE id = ?').get(info.lastInsertRowid));
});

// Ubah produk (nama, harga, stok)
router.put('/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM produk WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Produk tidak ditemukan' });
  const nama = req.body.nama ?? p.nama;
  const harga = req.body.harga ?? p.harga;
  const stok = req.body.stok ?? p.stok;
  if (!nama || !(harga >= 0) || !(stok >= 0)) return res.status(400).json({ error: 'Data tidak valid' });
  db.prepare('UPDATE produk SET nama = ?, harga = ?, stok = ? WHERE id = ?').run(nama, Math.round(harga), Math.round(stok), p.id);
  res.json(db.prepare('SELECT * FROM produk WHERE id = ?').get(p.id));
});

// Hapus produk
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM produk WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

module.exports = router;
