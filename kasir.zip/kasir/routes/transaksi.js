const express = require('express');
const db = require('../db');
const router = express.Router();

function ambil(id) {
  const t = db.prepare('SELECT * FROM transaksi WHERE id = ?').get(id);
  if (!t) return null;
  t.items = db.prepare('SELECT produk_id, nama, harga, qty FROM transaksi_item WHERE transaksi_id = ?').all(id);
  return t;
}

// Riwayat transaksi
router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM transaksi ORDER BY id DESC LIMIT 100').all());
});

router.get('/:id', (req, res) => {
  const t = ambil(req.params.id);
  if (!t) return res.status(404).json({ error: 'Transaksi tidak ditemukan' });
  res.json(t);
});

// Buat transaksi: hitung ulang di server, cek stok, kurangi stok
router.post('/', (req, res) => {
  const { items, potongan, metode, diterima } = req.body;
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Keranjang kosong' });
  if (!['tunai', 'qris'].includes(metode)) return res.status(400).json({ error: 'Metode pembayaran tidak valid' });

  const proses = db.transaction(() => {
    let subtotal = 0;
    const baris = [];
    for (const it of items) {
      const p = db.prepare('SELECT * FROM produk WHERE id = ?').get(it.id);
      const qty = parseInt(it.qty, 10);
      if (!p || !(qty > 0)) throw new Error('Item tidak valid');
      if (p.stok < qty) throw new Error(`Stok ${p.nama} tidak cukup`);
      subtotal += p.harga * qty;
      baris.push({ p, qty });
    }

    const nilai = Math.max(0, Number(potongan && potongan.nilai) || 0);
    const pot =
      potongan && potongan.tipe === 'pct'
        ? Math.round((subtotal * Math.min(nilai, 100)) / 100)
        : Math.min(Math.round(nilai), subtotal);
    const total = subtotal - pot;

    let dit = null;
    let kem = null;
    if (metode === 'tunai') {
      dit = Math.round(Number(diterima) || 0);
      if (dit < total) throw new Error('Uang diterima kurang dari total');
      kem = dit - total;
    }

    const info = db
      .prepare('INSERT INTO transaksi (waktu, subtotal, potongan, total, metode, diterima, kembalian) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(new Date().toISOString(), subtotal, pot, total, metode, dit, kem);
    const id = info.lastInsertRowid;
    db.prepare('UPDATE transaksi SET no_struk = ? WHERE id = ?').run('INV-' + String(id).padStart(4, '0'), id);

    const insItem = db.prepare('INSERT INTO transaksi_item (transaksi_id, produk_id, nama, harga, qty) VALUES (?, ?, ?, ?, ?)');
    const kurangi = db.prepare('UPDATE produk SET stok = stok - ? WHERE id = ?');
    for (const { p, qty } of baris) {
      insItem.run(id, p.id, p.nama, p.harga, qty);
      kurangi.run(qty, p.id);
    }
    return id;
  });

  try {
    res.status(201).json(ambil(proses()));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
