const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/produk', require('./routes/produk'));
app.use('/api/transaksi', require('./routes/transaksi'));

app.use((req, res) => res.status(404).json({ error: 'Tidak ditemukan' }));

app.listen(PORT, () => {
  console.log(`Kasir berjalan di http://localhost:${PORT}`);
});
